function openAccord(id) {
    accord = document.getElementById(id)

}